package CreationDocument;
import org.jdom2.*;
import org.jdom2.output.XMLOutputter;


public class Ex1_C{

  public static void main(String[] args) {
   
    Element racine = new Element("Sequence");
    	
    racine.setText("cacctttcaattttgtcgca");
         
    Document doc = new Document(racine);      
    
    // serialization du document qui est pour le moment en memoire
    XMLOutputter outputter = new XMLOutputter();
    try {
      outputter.output(doc, System.out);       
    }
    catch (Exception e) {
      System.err.println(e);
    }

  }

}
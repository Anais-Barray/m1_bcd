package genericiteNonBornee;

class Bouteille{


	private String contenu;
	public String getContenu(){return this.contenu;}
	public void setContenu(String contenu) {this.contenu = contenu;}
	public String toString(){return this.getContenu();}

}

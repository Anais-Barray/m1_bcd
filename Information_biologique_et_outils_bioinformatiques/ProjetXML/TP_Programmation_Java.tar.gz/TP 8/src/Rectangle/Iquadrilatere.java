package Rectangle;

public interface Iquadrilatere {
	
	int nbCotes=4;

	double perimetre();

}
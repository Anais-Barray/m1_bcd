package Rectangle;

/*public class Rectangle extends RectangleAbs {

	public Rectangle() {
		// TODO Auto-generated constructor stub
	}

}
*/
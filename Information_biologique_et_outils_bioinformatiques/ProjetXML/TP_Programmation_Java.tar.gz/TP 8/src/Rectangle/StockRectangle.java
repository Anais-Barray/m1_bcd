package Rectangle;

public class StockRectangle {

	public StockRectangle() {
		// TODO Auto-generated constructor stub
	}

}

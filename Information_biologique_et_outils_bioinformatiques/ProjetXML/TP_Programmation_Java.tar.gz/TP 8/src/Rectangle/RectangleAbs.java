package Rectangle;

public abstract class RectangleAbs implements Irectangle {

	public RectangleAbs() {

	}

}

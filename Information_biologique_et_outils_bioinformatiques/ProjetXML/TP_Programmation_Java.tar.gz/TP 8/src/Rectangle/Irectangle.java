package Rectangle;

public interface Irectangle extends Iquadrilatere{
	
	int angle = 90;

	double getLargeur();

	double getHauteur();

}

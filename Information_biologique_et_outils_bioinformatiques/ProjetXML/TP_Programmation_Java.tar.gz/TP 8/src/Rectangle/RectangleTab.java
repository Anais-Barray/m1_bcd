package Rectangle;
/*
public class RectangleTab extends RectangleAbs {

	public RectangleTab() {
		// TODO Auto-generated constructor stub
	}

}
*/
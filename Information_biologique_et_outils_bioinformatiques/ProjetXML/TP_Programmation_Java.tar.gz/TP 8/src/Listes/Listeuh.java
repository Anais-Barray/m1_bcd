package Listes;


public interface Listeuh {
	void add(Object element);
	boolean contains(Object o);
	Object get(int index);
	int size();

}


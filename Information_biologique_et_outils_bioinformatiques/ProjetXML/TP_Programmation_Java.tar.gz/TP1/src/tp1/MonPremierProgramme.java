package tp1;

import java.util.Scanner;

public class MonPremierProgramme {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner clavier = new Scanner(System.in);
		clavier.nextInt();
		clavier.close();
	}

}

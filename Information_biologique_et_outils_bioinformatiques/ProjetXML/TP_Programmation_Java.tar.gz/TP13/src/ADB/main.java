package ADB;

public class main {


	public static void main(String[] args) {
		ADB<String> m = new ADB<>("mammifere");
		ADB<String> pr = new ADB<>("poisson/reptile");
		ADB<String> o = new ADB<>("oiseau");
		ADB<String> mo = new ADB<>("mollusque");
		ADB<String> a = new ADB<>("arthropode");
		ADB<String> po = new ADB<>("Poils ?",m,pr);
		ADB<String> pl = new ADB<>("Plumes ?",o,po);
		ADB<String> c = new ADB<>("Coquille ?",mo,a);
		ADB<String> v = new ADB<>("Vertebre ?",pl,c);
		//System.out.println(v.toString());
		System.out.println(v.toStringDecalage(0));


	}

}

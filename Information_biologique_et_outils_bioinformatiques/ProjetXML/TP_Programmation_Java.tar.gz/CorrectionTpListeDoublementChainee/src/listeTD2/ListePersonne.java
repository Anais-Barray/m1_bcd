package listeTD2;

public class ListePersonne<T extends Personne> extends ListeDoublementChainee<T> {
	
}
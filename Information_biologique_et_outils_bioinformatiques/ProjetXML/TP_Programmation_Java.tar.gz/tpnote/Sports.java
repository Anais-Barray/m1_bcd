package cc;
// question 3
public enum Sports {
randonnee, fitness, danse, natation, equitation, athletisme;
}

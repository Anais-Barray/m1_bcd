package genericiteNonBornee;

class Bouteille{
	private String contenu;
	public String getContenu(){return this.contenu;}	
}

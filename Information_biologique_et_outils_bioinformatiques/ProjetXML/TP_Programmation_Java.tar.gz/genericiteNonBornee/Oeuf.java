package genericiteNonBornee;

class Oeuf{
	//....
	public double taille(){return 9;}
}

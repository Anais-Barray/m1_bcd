package VetementExam;

public enum Sports {
randonnee, fitness, danse, natation, equitation, athletisme;
}

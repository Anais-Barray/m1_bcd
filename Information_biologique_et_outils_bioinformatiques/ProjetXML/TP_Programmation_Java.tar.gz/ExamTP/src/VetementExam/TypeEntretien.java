package VetementExam;

public enum TypeEntretien {
lavageSec, lavageFroid, lavage30degres, lavage40degres, lavage60degres, lavage90degres, secheLingeInterdit, lavageAvecCouleursSemblables;
}

package Etudiant;

public enum SituationFinanciere {
	boursier, salarie, autre;
}

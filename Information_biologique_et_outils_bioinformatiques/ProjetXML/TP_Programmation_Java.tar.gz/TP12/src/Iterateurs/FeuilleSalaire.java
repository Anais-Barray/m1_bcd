package Iterateurs;

import java.util.Iterator;
import java.util.Spliterator;
import java.util.function.Consumer;

public class FeuilleSalaire implements Iterable {
	private Personne employeur = null;
	private Personne salarie = null;
	private String conventionCollective = "";
	private int nbHpayes = 0;
	private double prelevementF = 0;
	private double netApayer = 0;
	
	public FeuilleSalaire() {}
	public FeuilleSalaire(Personne e, Personne s, String cc, int nhp, double pf, double nap) {
		this.employeur = e;
		this.salarie = s;
		this.conventionCollective = cc;
		this.nbHpayes = nhp;
		this.prelevementF = pf;
		this.netApayer = nap;
	}



	public Iterator iterator() {
		return new IteratorFeuilleSalaire(tab);

	}


}

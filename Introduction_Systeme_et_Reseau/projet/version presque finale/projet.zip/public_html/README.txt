
projet : explorateur de fichier (explorateur.html)


fenêtre de gauche : arborescence des dossiers (liste.cgi)
- Affiche l'arborescence des dossiers, avec une indentation en fonction de leur profondeur dans l'arborescence
- Un lien racine permet de revenir au dossier d'origine.
- Un clic sur l'image du dossier permet de masquer ou d'afficher les sous dossiers qu'il contient (disfonctionnement).
- Un clic sur le nom du dossier permet d'afficher son contenu dans la fenêtre de droite.

fenêtre de droite : affichage du contenu (contenu.cgi)
- Affiche le contenu du dossier courant, en vérifiant s'il s'agit de dossiers ou de fichiers, et attribuant des images en conséquences (une image pour les dossiers, une image par extension connue, et une image par défaut quand l'extension du fichier n'est pas connue)
- Un clic sur l'image ou le nom du dossier permet d'afficher son contenu dans la fenêtre de droite
- Les icones sont rangés en fonction de leur type (d'abord les dossiers puis les fichiers) et de leur nom (ordre alphabétique)
- Un clic droit permet de faire apparaitre, en fonction de la position de la souris, un menu d'option (options non fonctionnelles)

Note: Essaie de code pour les fonctions de renommage/suppression de fichier et affichage de fichier texte (essai.cgi)

programme créé par Anaïs Barray, Kevin Sugier et Jean de Montigny, Master 1 BCD


